#!/bin/bash
# TradeX User — Mac launcher (self-contained: Python is bundled, nothing to install).
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR" || exit 1
case "$(uname -m)" in
  arm64) RT="$DIR/runtime/mac-arm64" ;;
  *)     RT="$DIR/runtime/mac-x64" ;;
esac
PY="$RT/python/bin/python3"
if [ ! -x "$PY" ]; then echo "Bundled runtime missing ($PY) — download TradeX User again."; read -r -p "Press Enter to close" _; exit 1; fi
export PYTHONPATH="$DIR/lib:$RT/site:$DIR" PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1
while true; do
  "$PY" -m tradex_user.main "$@"
  code=$?
  [ $code -eq 0 ] && break
  if [ $code -eq 2 ] || [ $code -eq 3 ] || [ $code -eq 4 ] || [ $code -eq 6 ]; then read -r -p "Press Enter to close" _; break; fi
  echo "TradeX User stopped (code $code) — restarting in 15s. Ctrl+C to quit."
  sleep 15
done
