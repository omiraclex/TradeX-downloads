@echo off
REM TradeX Desktop — double-click to open the TradeX window (Python is bundled).
cd /d "%~dp0app"
set "PY=%~dp0app\runtime\win-x64\python\pythonw.exe"
if not exist "%PY%" (
  echo TradeX is incomplete - please download it again.
  pause & exit /b 1
)
set "PYTHONPATH=%~dp0app\lib;%~dp0app\runtime\win-x64\site;%~dp0app"
set PYTHONNOUSERSITE=1
set PYTHONDONTWRITEBYTECODE=1
set PYTHONUTF8=1
start "" "%PY%" -P -m tradex_user.gui
