@echo off
REM TradeX User — Windows launcher (self-contained: Python is bundled, nothing to install).
chcp 65001 >nul
cd /d "%~dp0"
set "PY=%~dp0runtime\win-x64\python\python.exe"
if not exist "%PY%" (
  echo Bundled runtime missing - download TradeX User again.
  pause & exit /b 1
)
set "PYTHONPATH=%~dp0lib;%~dp0runtime\win-x64\site;%~dp0"
set PYTHONNOUSERSITE=1
set PYTHONDONTWRITEBYTECODE=1
set PYTHONUTF8=1
:loop
"%PY%" -m tradex_user.main %*
set CODE=%ERRORLEVEL%
if %CODE%==0 goto end
if %CODE%==2 goto stop
if %CODE%==3 goto stop
if %CODE%==4 goto stop
if %CODE%==6 goto stop
echo TradeX User stopped (code %CODE%) - restarting in 15s. Ctrl+C to quit.
timeout /t 15 /nobreak >nul
goto loop
:stop
pause
:end
